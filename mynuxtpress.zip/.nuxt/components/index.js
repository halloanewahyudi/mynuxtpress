import { wrapFunctional } from './utils'

export { default as Berita } from '../..\\components\\Berita.vue'
export { default as JadwalSholat } from '../..\\components\\JadwalSholat.vue'
export { default as Navbar } from '../..\\components\\Navbar.vue'
export { default as NuxtLogo } from '../..\\components\\NuxtLogo.vue'
export { default as Post } from '../..\\components\\Post.vue'
export { default as Slideshow } from '../..\\components\\Slideshow.vue'
export { default as Tutorial } from '../..\\components\\Tutorial.vue'

export const LazyBerita = import('../..\\components\\Berita.vue' /* webpackChunkName: "components/berita" */).then(c => wrapFunctional(c.default || c))
export const LazyJadwalSholat = import('../..\\components\\JadwalSholat.vue' /* webpackChunkName: "components/jadwal-sholat" */).then(c => wrapFunctional(c.default || c))
export const LazyNavbar = import('../..\\components\\Navbar.vue' /* webpackChunkName: "components/navbar" */).then(c => wrapFunctional(c.default || c))
export const LazyNuxtLogo = import('../..\\components\\NuxtLogo.vue' /* webpackChunkName: "components/nuxt-logo" */).then(c => wrapFunctional(c.default || c))
export const LazyPost = import('../..\\components\\Post.vue' /* webpackChunkName: "components/post" */).then(c => wrapFunctional(c.default || c))
export const LazySlideshow = import('../..\\components\\Slideshow.vue' /* webpackChunkName: "components/slideshow" */).then(c => wrapFunctional(c.default || c))
export const LazyTutorial = import('../..\\components\\Tutorial.vue' /* webpackChunkName: "components/tutorial" */).then(c => wrapFunctional(c.default || c))
